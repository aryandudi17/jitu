import React from 'react';
import DiceGame from './DiceGame';
import MinesGame from './MinesGame';

const GameModal = ({ game, onClose }) => {
  if (!game) return null;

  const renderGame = () => {
    switch (game.name.toLowerCase()) {
      case 'dice':
        return <DiceGame onClose={onClose} />;
      case 'mines':
        return <MinesGame onClose={onClose} />;
      default:
        return (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-card p-8 rounded-lg max-w-md w-full text-center">
              <h2 className="text-2xl font-bold mb-4">{game.name}</h2>
              <p className="text-muted-foreground mb-6">
                This game is coming soon! We're working hard to bring you the best gaming experience.
              </p>
              <button 
                onClick={onClose}
                className="bg-primary text-primary-foreground px-6 py-2 rounded hover:bg-primary/90 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        );
    }
  };

  return renderGame();
};

export default GameModal;

