import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  User, 
  Wallet, 
  Settings, 
  History, 
  Trophy, 
  Gift,
  LogOut,
  Eye,
  EyeOff,
  Plus,
  Minus
} from 'lucide-react';

const UserProfile = ({ user, onClose, onLogout, onUpdateBalance }) => {
  const [activeTab, setActiveTab] = useState('profile');
  const [showBalance, setShowBalance] = useState(true);
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'wallet', label: 'Wallet', icon: Wallet },
    { id: 'history', label: 'History', icon: History },
    { id: 'rewards', label: 'Rewards', icon: Trophy },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    if (amount > 0) {
      onUpdateBalance(user.balance + amount);
      setDepositAmount('');
    }
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (amount > 0 && amount <= user.balance) {
      onUpdateBalance(user.balance - amount);
      setWithdrawAmount('');
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="h-10 w-10 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-bold">{user.username}</h3>
              <p className="text-muted-foreground">Member since 2024</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-muted p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-primary">47</div>
                <div className="text-sm text-muted-foreground">Games Played</div>
              </div>
              <div className="bg-muted p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-green-500">$2,340</div>
                <div className="text-sm text-muted-foreground">Total Won</div>
              </div>
              <div className="bg-muted p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-500">Gold</div>
                <div className="text-sm text-muted-foreground">VIP Level</div>
              </div>
              <div className="bg-muted p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-purple-500">12</div>
                <div className="text-sm text-muted-foreground">Achievements</div>
              </div>
            </div>
          </div>
        );

      case 'wallet':
        return (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-primary/20 to-primary/10 p-6 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Current Balance</span>
                <button
                  onClick={() => setShowBalance(!showBalance)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  {showBalance ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </button>
              </div>
              <div className="text-3xl font-bold text-primary">
                {showBalance ? `$${user.balance.toFixed(2)}` : '••••••'}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-3">
                <h4 className="font-semibold flex items-center">
                  <Plus className="h-4 w-4 mr-2 text-green-500" />
                  Deposit
                </h4>
                <input
                  type="number"
                  placeholder="Amount"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full p-2 border rounded bg-background"
                />
                <Button onClick={handleDeposit} className="w-full bg-green-600 hover:bg-green-700">
                  Deposit
                </Button>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold flex items-center">
                  <Minus className="h-4 w-4 mr-2 text-red-500" />
                  Withdraw
                </h4>
                <input
                  type="number"
                  placeholder="Amount"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="w-full p-2 border rounded bg-background"
                  max={user.balance}
                />
                <Button onClick={handleWithdraw} className="w-full bg-red-600 hover:bg-red-700">
                  Withdraw
                </Button>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold">Recent Transactions</h4>
              <div className="space-y-2">
                {[
                  { type: 'win', amount: 25.50, game: 'Dice', time: '2 hours ago' },
                  { type: 'bet', amount: -10.00, game: 'Mines', time: '3 hours ago' },
                  { type: 'deposit', amount: 100.00, game: 'Deposit', time: '1 day ago' },
                ].map((tx, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted rounded">
                    <div>
                      <div className="font-medium">{tx.game}</div>
                      <div className="text-sm text-muted-foreground">{tx.time}</div>
                    </div>
                    <div className={`font-semibold ${
                      tx.amount > 0 ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {tx.amount > 0 ? '+' : ''}${Math.abs(tx.amount).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'history':
        return (
          <div className="space-y-4">
            <h4 className="font-semibold">Game History</h4>
            <div className="space-y-2">
              {[
                { game: 'Dice', result: 'Win', amount: 25.50, time: '2 hours ago' },
                { game: 'Mines', result: 'Loss', amount: -10.00, time: '3 hours ago' },
                { game: 'Plinko', result: 'Win', amount: 15.75, time: '5 hours ago' },
                { game: 'Crash', result: 'Win', amount: 42.30, time: '1 day ago' },
              ].map((game, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted rounded">
                  <div>
                    <div className="font-medium">{game.game}</div>
                    <div className="text-sm text-muted-foreground">{game.time}</div>
                  </div>
                  <div className="text-right">
                    <div className={`font-semibold ${
                      game.result === 'Win' ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {game.result}
                    </div>
                    <div className={`text-sm ${
                      game.amount > 0 ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {game.amount > 0 ? '+' : ''}${Math.abs(game.amount).toFixed(2)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'rewards':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Trophy className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold">VIP Gold Member</h3>
              <p className="text-muted-foreground">Enjoy exclusive benefits and rewards</p>
            </div>

            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Daily Bonus</span>
                  <Gift className="h-5 w-5 text-primary" />
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  Claim your daily bonus to boost your balance
                </p>
                <Button className="w-full">Claim $5.00</Button>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Weekly Cashback</span>
                  <span className="text-sm text-green-500">5%</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Get 5% cashback on your weekly losses
                </p>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Referral Bonus</span>
                  <span className="text-sm text-blue-500">$10</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Earn $10 for each friend you refer
                </p>
              </div>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <h4 className="font-semibold">Account Settings</h4>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-muted rounded">
                  <span>Email Notifications</span>
                  <input type="checkbox" defaultChecked className="toggle" />
                </div>
                
                <div className="flex items-center justify-between p-3 bg-muted rounded">
                  <span>Two-Factor Authentication</span>
                  <input type="checkbox" className="toggle" />
                </div>
                
                <div className="flex items-center justify-between p-3 bg-muted rounded">
                  <span>Marketing Communications</span>
                  <input type="checkbox" defaultChecked className="toggle" />
                </div>
              </div>

              <div className="space-y-3">
                <h5 className="font-medium">Responsible Gaming</h5>
                <Button variant="outline" className="w-full">
                  Set Deposit Limits
                </Button>
                <Button variant="outline" className="w-full">
                  Set Session Time Limits
                </Button>
                <Button variant="outline" className="w-full text-red-500">
                  Self-Exclusion Options
                </Button>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl bg-card max-h-[90vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-2xl">Account</CardTitle>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onLogout} className="text-red-500">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
            <Button variant="ghost" onClick={onClose}>×</Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="flex">
            {/* Sidebar */}
            <div className="w-48 bg-muted/50 p-4 space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-primary text-primary-foreground'
                        : 'hover:bg-muted'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="text-sm">{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Content */}
            <div className="flex-1 p-6 overflow-y-auto max-h-[70vh]">
              {renderTabContent()}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserProfile;

