import React from 'react';
import GameCard from './GameCard';
import { Button } from './ui/button';

const GameGrid = ({ games, title, onGameClick }) => {
  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl md:text-2xl font-bold text-foreground">{title}</h2>
        <Button variant="ghost" className="text-primary hover:text-primary/80 text-sm md:text-base">
          View All →
        </Button>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4">
        {games.map((game) => (
          <GameCard 
            key={game.id} 
            game={game} 
            onClick={() => onGameClick(game)}
          />
        ))}
      </div>
    </section>
  );
};

export default GameGrid;