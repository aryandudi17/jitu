import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Bomb, Gem, DollarSign } from 'lucide-react';

const MinesGame = ({ onClose }) => {
  const [betAmount, setBetAmount] = useState(1.00);
  const [minesCount, setMinesCount] = useState(3);
  const [gameState, setGameState] = useState('betting'); // betting, playing, ended
  const [board, setBoard] = useState([]);
  const [revealed, setRevealed] = useState([]);
  const [balance, setBalance] = useState(100.00);
  const [currentMultiplier, setCurrentMultiplier] = useState(1);
  const [gemsFound, setGemsFound] = useState(0);

  const BOARD_SIZE = 25;

  useEffect(() => {
    if (gameState === 'playing') {
      calculateMultiplier();
    }
  }, [gemsFound, minesCount]);

  const initializeGame = () => {
    if (betAmount > balance) return;
    
    // Create board with mines
    const newBoard = Array(BOARD_SIZE).fill('gem');
    const minePositions = [];
    
    while (minePositions.length < minesCount) {
      const pos = Math.floor(Math.random() * BOARD_SIZE);
      if (!minePositions.includes(pos)) {
        minePositions.push(pos);
        newBoard[pos] = 'mine';
      }
    }
    
    setBoard(newBoard);
    setRevealed(Array(BOARD_SIZE).fill(false));
    setGameState('playing');
    setGemsFound(0);
    setCurrentMultiplier(1);
    setBalance(prev => prev - betAmount);
  };

  const calculateMultiplier = () => {
    if (gemsFound === 0) {
      setCurrentMultiplier(1);
      return;
    }
    
    const safeSpots = BOARD_SIZE - minesCount;
    let multiplier = 1;
    
    for (let i = 0; i < gemsFound; i++) {
      multiplier *= (safeSpots - i) / (BOARD_SIZE - minesCount - i);
    }
    
    setCurrentMultiplier(multiplier);
  };

  const revealTile = (index) => {
    if (gameState !== 'playing' || revealed[index]) return;
    
    const newRevealed = [...revealed];
    newRevealed[index] = true;
    setRevealed(newRevealed);
    
    if (board[index] === 'mine') {
      // Game over - hit a mine
      setGameState('ended');
      // Reveal all mines
      const allMinesRevealed = [...newRevealed];
      board.forEach((tile, i) => {
        if (tile === 'mine') allMinesRevealed[i] = true;
      });
      setRevealed(allMinesRevealed);
    } else {
      // Found a gem
      setGemsFound(prev => prev + 1);
    }
  };

  const cashOut = () => {
    if (gameState !== 'playing') return;
    
    const winAmount = betAmount * currentMultiplier;
    setBalance(prev => prev + winAmount);
    setGameState('ended');
  };

  const resetGame = () => {
    setGameState('betting');
    setBoard([]);
    setRevealed([]);
    setGemsFound(0);
    setCurrentMultiplier(1);
  };

  const getTileContent = (index) => {
    if (!revealed[index]) {
      return <div className="w-full h-full bg-muted hover:bg-muted/80 transition-colors" />;
    }
    
    if (board[index] === 'mine') {
      return (
        <div className="w-full h-full bg-red-500 flex items-center justify-center">
          <Bomb className="h-6 w-6 text-white" />
        </div>
      );
    }
    
    return (
      <div className="w-full h-full bg-green-500 flex items-center justify-center">
        <Gem className="h-6 w-6 text-white" />
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-6xl bg-card">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-2xl">Mines Game</CardTitle>
          <Button variant="ghost" onClick={onClose}>×</Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Game Controls */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Bet Amount</label>
                <Input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
                  step="0.01"
                  min="0.01"
                  max={balance}
                  disabled={gameState === 'playing'}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Mines: {minesCount}
                </label>
                <input
                  type="range"
                  min="1"
                  max="24"
                  value={minesCount}
                  onChange={(e) => setMinesCount(parseInt(e.target.value))}
                  className="w-full"
                  disabled={gameState === 'playing'}
                />
              </div>

              {gameState === 'betting' && (
                <Button 
                  onClick={initializeGame} 
                  disabled={betAmount > balance}
                  className="w-full neon-glow"
                  size="lg"
                >
                  Start Game - ${betAmount.toFixed(2)}
                </Button>
              )}

              {gameState === 'playing' && (
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded">
                    <div className="text-sm text-muted-foreground">Current Multiplier</div>
                    <div className="text-2xl font-bold text-primary">
                      {currentMultiplier.toFixed(2)}x
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Potential Win: ${(betAmount * currentMultiplier).toFixed(2)}
                    </div>
                  </div>
                  
                  <Button 
                    onClick={cashOut}
                    className="w-full bg-green-600 hover:bg-green-700"
                    size="lg"
                    disabled={gemsFound === 0}
                  >
                    <DollarSign className="h-4 w-4 mr-2" />
                    Cash Out - ${(betAmount * currentMultiplier).toFixed(2)}
                  </Button>
                </div>
              )}

              {gameState === 'ended' && (
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded text-center">
                    {board.some((tile, i) => tile === 'mine' && revealed[i]) ? (
                      <div>
                        <div className="text-red-500 font-bold text-xl mb-2">BOOM!</div>
                        <div className="text-sm">You hit a mine!</div>
                      </div>
                    ) : (
                      <div>
                        <div className="text-green-500 font-bold text-xl mb-2">CASHED OUT!</div>
                        <div className="text-sm">
                          Won: ${(betAmount * currentMultiplier).toFixed(2)}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <Button 
                    onClick={resetGame}
                    className="w-full"
                    size="lg"
                  >
                    Play Again
                  </Button>
                </div>
              )}

              <div className="text-center">
                <div className="text-sm text-muted-foreground">Balance</div>
                <div className="text-xl font-bold text-primary">${balance.toFixed(2)}</div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-muted p-3 rounded">
                  <div className="text-muted-foreground">Gems Found</div>
                  <div className="font-semibold text-green-500">{gemsFound}</div>
                </div>
                <div className="bg-muted p-3 rounded">
                  <div className="text-muted-foreground">Mines</div>
                  <div className="font-semibold text-red-500">{minesCount}</div>
                </div>
              </div>
            </div>

            {/* Game Board */}
            <div className="lg:col-span-2">
              <div className="grid grid-cols-5 gap-2 max-w-md mx-auto">
                {Array.from({ length: BOARD_SIZE }, (_, index) => (
                  <button
                    key={index}
                    onClick={() => revealTile(index)}
                    disabled={gameState !== 'playing' || revealed[index]}
                    className="aspect-square rounded border-2 border-border hover:border-primary transition-colors disabled:cursor-not-allowed"
                  >
                    {getTileContent(index)}
                  </button>
                ))}
              </div>
              
              {gameState === 'betting' && (
                <div className="text-center mt-8 text-muted-foreground">
                  <p>Set your bet and number of mines, then start the game!</p>
                  <p className="text-sm mt-2">Find gems while avoiding mines to win.</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MinesGame;

