import React from 'react';
import { Play, Star } from 'lucide-react';

const GameCard = ({ game, onClick }) => {
  return (
    <div 
      className="game-card bg-card rounded-lg overflow-hidden cursor-pointer group relative"
      onClick={() => onClick(game)}
    >
      <div className="aspect-[4/3] relative overflow-hidden">
        <img 
          src={game.image} 
          alt={game.name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <div className="bg-primary rounded-full p-3">
            <Play className="h-6 w-6 text-primary-foreground fill-current" />
          </div>
        </div>

        {/* Hot/New Badge */}
        {game.badge && (
          <div className="absolute top-2 left-2">
            <span className={`px-2 py-1 text-xs font-bold rounded-full ${
              game.badge === 'HOT' 
                ? 'bg-red-500 text-white' 
                : 'bg-green-500 text-white'
            }`}>
              {game.badge}
            </span>
          </div>
        )}

        {/* Favorite */}
        <button className="absolute top-2 right-2 p-1 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity">
          <Star className="h-4 w-4 text-white" />
        </button>
      </div>

      <div className="p-3">
        <h3 className="font-semibold text-card-foreground truncate">{game.name}</h3>
        <p className="text-sm text-muted-foreground">{game.provider}</p>
        
        {game.rtp && (
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-muted-foreground">RTP</span>
            <span className="text-xs font-semibold text-primary">{game.rtp}%</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default GameCard;

