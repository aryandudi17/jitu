import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Search, User, Wallet, Settings, Menu } from 'lucide-react';
import stakeLogo from '../assets/nMe3LksjhXh5.jpg';

const Header = ({ user, onLoginClick, onProfileClick, onMenuClick }) => {
  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Mobile Menu Button & Logo */}
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="md:hidden"
              onClick={onMenuClick}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <img 
              src={stakeLogo} 
              alt="Stake" 
              className="h-8 w-8 rounded-full"
            />
            <span className="text-2xl font-bold text-primary">Stake</span>
          </div>

          {/* Navigation - Hidden on mobile */}
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#casino" className="text-foreground hover:text-primary transition-colors">
              Casino
            </a>
            <a href="#sports" className="text-foreground hover:text-primary transition-colors">
              Sports
            </a>
            <a href="#promotions" className="text-foreground hover:text-primary transition-colors">
              Promotions
            </a>
            <a href="#vip" className="text-foreground hover:text-primary transition-colors">
              VIP
            </a>
          </nav>

          {/* Search Bar - Hidden on mobile */}
          <div className="hidden lg:flex items-center relative">
            <Search className="absolute left-3 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search games..." 
              className="pl-10 w-64 bg-background"
            />
          </div>

          {/* User Actions */}
          <div className="flex items-center space-x-2">
            {user ? (
              <>
                <Button variant="outline" size="sm" className="hidden sm:flex">
                  <Wallet className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">${user.balance.toFixed(2)}</span>
                  <span className="sm:hidden">${Math.floor(user.balance)}</span>
                </Button>
                <Button variant="ghost" size="sm" onClick={onProfileClick}>
                  <User className="h-4 w-4 sm:mr-2" />
                  <span className="hidden sm:inline">{user.username}</span>
                </Button>
              </>
            ) : (
              <>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={onLoginClick}
                  className="hidden sm:flex"
                >
                  Login
                </Button>
                <Button 
                  size="sm"
                  onClick={onLoginClick}
                  className="neon-glow"
                >
                  <span className="hidden sm:inline">Register</span>
                  <span className="sm:hidden">Join</span>
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="mt-3 lg:hidden">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search games..." 
              className="pl-10 w-full bg-background"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

