import React from 'react';
import { Button } from './ui/button';
import { ArrowRight, Zap, Trophy, Gift } from 'lucide-react';

const HeroSection = () => {
  return (
    <div className="stake-gradient rounded-lg p-4 md:p-8 mb-8 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 border border-white rounded-full"></div>
        <div className="absolute top-20 right-20 w-16 h-16 border border-white rounded-full"></div>
        <div className="absolute bottom-10 left-1/3 w-12 h-12 border border-white rounded-full"></div>
      </div>

      <div className="relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
            Welcome to <span className="text-primary">Stake</span>
          </h1>
          <p className="text-base md:text-xl text-gray-200 mb-6">
            The world's leading crypto casino and sportsbook. Play thousands of games, bet on sports, and win big!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 mb-6 md:mb-8">
            <Button size="lg" className="neon-glow text-sm md:text-base">
              Start Playing
              <ArrowRight className="ml-2 h-4 w-4 md:h-5 md:w-5" />
            </Button>
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-black text-sm md:text-base">
              Learn More
            </Button>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
            <div className="flex items-center space-x-3 text-white">
              <div className="bg-primary/20 p-2 rounded-lg flex-shrink-0">
                <Zap className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-sm md:text-base">Instant Deposits</h3>
                <p className="text-xs md:text-sm text-gray-300">Lightning fast crypto transactions</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 text-white">
              <div className="bg-primary/20 p-2 rounded-lg flex-shrink-0">
                <Trophy className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-sm md:text-base">Provably Fair</h3>
                <p className="text-xs md:text-sm text-gray-300">Transparent and verifiable games</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 text-white">
              <div className="bg-primary/20 p-2 rounded-lg flex-shrink-0">
                <Gift className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-sm md:text-base">VIP Rewards</h3>
                <p className="text-xs md:text-sm text-gray-300">Exclusive bonuses and perks</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;

