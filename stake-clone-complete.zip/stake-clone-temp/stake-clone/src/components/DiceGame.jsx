import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dice1, Dice2, Dice3, Dice4, Dice5, Dice6, TrendingUp, TrendingDown } from 'lucide-react';

const DiceGame = ({ onClose }) => {
  const [betAmount, setBetAmount] = useState(1.00);
  const [prediction, setPrediction] = useState('over');
  const [target, setTarget] = useState(50);
  const [result, setResult] = useState(null);
  const [isRolling, setIsRolling] = useState(false);
  const [balance, setBalance] = useState(100.00);

  const diceIcons = [Dice1, Dice2, Dice3, Dice4, Dice5, Dice6];
  
  const rollDice = () => {
    if (betAmount > balance) return;
    
    setIsRolling(true);
    setResult(null);
    
    setTimeout(() => {
      const roll = Math.floor(Math.random() * 100) + 1;
      const won = (prediction === 'over' && roll > target) || (prediction === 'under' && roll < target);
      
      const multiplier = prediction === 'over' 
        ? (99 / (100 - target)).toFixed(2)
        : (99 / target).toFixed(2);
      
      const winAmount = won ? betAmount * multiplier : 0;
      
      setResult({
        roll,
        won,
        winAmount: parseFloat(winAmount.toFixed(2)),
        multiplier: parseFloat(multiplier)
      });
      
      setBalance(prev => won ? prev + winAmount - betAmount : prev - betAmount);
      setIsRolling(false);
    }, 2000);
  };

  const getMultiplier = () => {
    return prediction === 'over' 
      ? (99 / (100 - target)).toFixed(2)
      : (99 / target).toFixed(2);
  };

  const getWinChance = () => {
    return prediction === 'over' 
      ? (100 - target).toFixed(1)
      : target.toFixed(1);
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl bg-card">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-2xl">Dice Game</CardTitle>
          <Button variant="ghost" onClick={onClose}>×</Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Game Controls */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Bet Amount</label>
                <Input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
                  step="0.01"
                  min="0.01"
                  max={balance}
                />
                <div className="flex gap-2 mt-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setBetAmount(prev => Math.max(0.01, prev / 2))}
                  >
                    1/2
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setBetAmount(prev => Math.min(balance, prev * 2))}
                  >
                    2x
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setBetAmount(balance)}
                  >
                    Max
                  </Button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Prediction</label>
                <div className="flex gap-2">
                  <Button
                    variant={prediction === 'under' ? 'default' : 'outline'}
                    onClick={() => setPrediction('under')}
                    className="flex-1"
                  >
                    <TrendingDown className="h-4 w-4 mr-2" />
                    Under
                  </Button>
                  <Button
                    variant={prediction === 'over' ? 'default' : 'outline'}
                    onClick={() => setPrediction('over')}
                    className="flex-1"
                  >
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Over
                  </Button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Target: {target}
                </label>
                <input
                  type="range"
                  min="1"
                  max="99"
                  value={target}
                  onChange={(e) => setTarget(parseInt(e.target.value))}
                  className="w-full"
                />
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-muted p-3 rounded">
                  <div className="text-muted-foreground">Win Chance</div>
                  <div className="font-semibold text-primary">{getWinChance()}%</div>
                </div>
                <div className="bg-muted p-3 rounded">
                  <div className="text-muted-foreground">Multiplier</div>
                  <div className="font-semibold text-primary">{getMultiplier()}x</div>
                </div>
              </div>

              <Button 
                onClick={rollDice} 
                disabled={isRolling || betAmount > balance}
                className="w-full neon-glow"
                size="lg"
              >
                {isRolling ? 'Rolling...' : `Roll Dice - $${betAmount.toFixed(2)}`}
              </Button>

              <div className="text-center">
                <div className="text-sm text-muted-foreground">Balance</div>
                <div className="text-xl font-bold text-primary">${balance.toFixed(2)}</div>
              </div>
            </div>

            {/* Game Display */}
            <div className="flex flex-col items-center justify-center space-y-6">
              <div className="text-center">
                <div className="text-6xl font-bold mb-4">
                  {isRolling ? (
                    <div className="animate-spin">🎲</div>
                  ) : result ? (
                    result.roll
                  ) : (
                    '?'
                  )}
                </div>
                
                {result && (
                  <div className="space-y-2">
                    <div className={`text-2xl font-bold ${result.won ? 'text-green-500' : 'text-red-500'}`}>
                      {result.won ? 'WIN!' : 'LOSE!'}
                    </div>
                    <div className="text-lg">
                      Roll: {result.roll} | Target: {prediction} {target}
                    </div>
                    {result.won && (
                      <div className="text-primary font-semibold">
                        Won: ${result.winAmount.toFixed(2)} ({result.multiplier}x)
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Visual representation */}
              <div className="w-full max-w-sm">
                <div className="relative h-8 bg-muted rounded-full overflow-hidden">
                  <div 
                    className={`absolute top-0 left-0 h-full transition-all duration-300 ${
                      prediction === 'under' ? 'bg-red-500' : 'bg-transparent'
                    }`}
                    style={{ width: `${target}%` }}
                  />
                  <div 
                    className={`absolute top-0 right-0 h-full transition-all duration-300 ${
                      prediction === 'over' ? 'bg-green-500' : 'bg-transparent'
                    }`}
                    style={{ width: `${100 - target}%` }}
                  />
                  {result && (
                    <div 
                      className="absolute top-0 w-1 h-full bg-white border-2 border-primary transition-all duration-500"
                      style={{ left: `${result.roll}%` }}
                    />
                  )}
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>0</span>
                  <span>{target}</span>
                  <span>100</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DiceGame;

