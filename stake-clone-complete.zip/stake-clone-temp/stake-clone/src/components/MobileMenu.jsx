import React from 'react';
import { Button } from './ui/button';
import { 
  Home, 
  Gamepad2, 
  Trophy, 
  Zap, 
  Star, 
  Gift, 
  Users,
  TrendingUp,
  Dice1,
  Spade,
  X
} from 'lucide-react';

const MobileMenu = ({ isOpen, onClose, activeSection, setActiveSection }) => {
  const menuItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'casino', label: 'Casino', icon: Gamepad2 },
    { id: 'live-casino', label: 'Live Casino', icon: Users },
    { id: 'sports', label: 'Sports', icon: Trophy },
    { id: 'originals', label: 'Stake Originals', icon: Star },
    { id: 'slots', label: 'Slots', icon: Zap },
    { id: 'table-games', label: 'Table Games', icon: Spade },
    { id: 'game-shows', label: 'Game Shows', icon: TrendingUp },
    { id: 'promotions', label: 'Promotions', icon: Gift },
    { id: 'vip', label: 'VIP', icon: Dice1 },
  ];

  if (!isOpen) return null;

  const handleItemClick = (itemId) => {
    setActiveSection(itemId);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 md:hidden">
      <div className="bg-sidebar w-80 h-full overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
          <h2 className="text-lg font-semibold text-sidebar-foreground">Menu</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-4">
          <nav className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`sidebar-item w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-all ${
                    activeSection === item.id
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground border-l-4 border-primary'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Recent Games */}
          <div className="mt-8">
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 px-3">
              RECENT GAMES
            </h3>
            <div className="space-y-2">
              {['Dice', 'Mines', 'Plinko', 'Crash'].map((game) => (
                <button
                  key={game}
                  className="sidebar-item w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left text-sm text-sidebar-foreground hover:bg-sidebar-accent/50"
                >
                  <div className="w-6 h-6 bg-primary/20 rounded flex items-center justify-center">
                    <Gamepad2 className="h-3 w-3 text-primary" />
                  </div>
                  <span>{game}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Live Stats */}
          <div className="mt-8 p-3 bg-card rounded-lg">
            <h3 className="text-sm font-semibold text-card-foreground mb-2">
              Live Stats
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Players Online</span>
                <span className="text-primary font-semibold">47,832</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Games Played</span>
                <span className="text-primary font-semibold">2.1M</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Wagered</span>
                <span className="text-primary font-semibold">$15.2M</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileMenu;

