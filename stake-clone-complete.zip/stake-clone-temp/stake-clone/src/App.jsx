import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MobileMenu from './components/MobileMenu';
import HeroSection from './components/HeroSection';
import GameGrid from './components/GameGrid';
import GameModal from './components/GameModal';
import LoginModal from './components/LoginModal';
import UserProfile from './components/UserProfile';
import './App.css';

// Mock game data
const mockGames = {
  featured: [
    {
      id: 1,
      name: 'Dice',
      provider: 'Stake Originals',
      image: '/src/assets/HczQ8Bqprhkn.jpg',
      rtp: 99,
      badge: 'HOT'
    },
    {
      id: 2,
      name: 'Mines',
      provider: 'Stake Originals',
      image: '/src/assets/nxr7e2gX4GdY.jpg',
      rtp: 97,
      badge: 'NEW'
    },
    {
      id: 3,
      name: 'Plinko',
      provider: 'Stake Originals',
      image: '/src/assets/xlvlfnvBl9jL.jpg',
      rtp: 99
    },
    {
      id: 4,
      name: 'Crash',
      provider: 'Stake Originals',
      image: '/src/assets/S0G7jHaszfeU.jpg',
      rtp: 99,
      badge: 'HOT'
    },
    {
      id: 5,
      name: 'Blackjack',
      provider: 'Evolution',
      image: '/src/assets/SqN2gjd4KiIT.webp',
      rtp: 99.5
    }
  ],
  slots: [
    {
      id: 6,
      name: 'Sweet Bonanza',
      provider: 'Pragmatic Play',
      image: '/src/assets/xlvlfnvBl9jL.jpg',
      rtp: 96.5,
      badge: 'HOT'
    },
    {
      id: 7,
      name: 'Gates of Olympus',
      provider: 'Pragmatic Play',
      image: '/src/assets/S0G7jHaszfeU.jpg',
      rtp: 96.5
    },
    {
      id: 8,
      name: 'Book of Dead',
      provider: 'Play\'n GO',
      image: '/src/assets/SqN2gjd4KiIT.webp',
      rtp: 96.2
    },
    {
      id: 9,
      name: 'Starburst',
      provider: 'NetEnt',
      image: '/src/assets/HczQ8Bqprhkn.jpg',
      rtp: 96.1
    },
    {
      id: 10,
      name: 'Gonzo\'s Quest',
      provider: 'NetEnt',
      image: '/src/assets/nxr7e2gX4GdY.jpg',
      rtp: 95.97
    }
  ],
  originals: [
    {
      id: 11,
      name: 'Keno',
      provider: 'Stake Originals',
      image: '/src/assets/HczQ8Bqprhkn.jpg',
      rtp: 95
    },
    {
      id: 12,
      name: 'Wheel',
      provider: 'Stake Originals',
      image: '/src/assets/nxr7e2gX4GdY.jpg',
      rtp: 97
    },
    {
      id: 13,
      name: 'Limbo',
      provider: 'Stake Originals',
      image: '/src/assets/xlvlfnvBl9jL.jpg',
      rtp: 99
    },
    {
      id: 14,
      name: 'Hilo',
      provider: 'Stake Originals',
      image: '/src/assets/S0G7jHaszfeU.jpg',
      rtp: 99
    }
  ]
};

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [selectedGame, setSelectedGame] = useState(null);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [user, setUser] = useState(null);

  const handleGameClick = (game) => {
    setSelectedGame(game);
  };

  const closeGameModal = () => {
    setSelectedGame(null);
  };

  const handleLogin = (userData) => {
    setUser(userData);
    setShowLoginModal(false);
  };

  const handleLogout = () => {
    setUser(null);
    setShowUserProfile(false);
  };

  const handleUpdateBalance = (newBalance) => {
    setUser(prev => ({ ...prev, balance: newBalance }));
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'home':
        return (
          <div>
            <HeroSection />
            <GameGrid 
              games={mockGames.featured} 
              title="Featured Games" 
              onGameClick={handleGameClick}
            />
            <GameGrid 
              games={mockGames.originals} 
              title="Stake Originals" 
              onGameClick={handleGameClick}
            />
            <GameGrid 
              games={mockGames.slots} 
              title="Popular Slots" 
              onGameClick={handleGameClick}
            />
          </div>
        );
      case 'casino':
        return (
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-6">Casino Games</h1>
            <GameGrid 
              games={[...mockGames.featured, ...mockGames.slots]} 
              title="All Casino Games" 
              onGameClick={handleGameClick}
            />
          </div>
        );
      case 'originals':
        return (
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-6">Stake Originals</h1>
            <GameGrid 
              games={mockGames.originals} 
              title="Original Games" 
              onGameClick={handleGameClick}
            />
          </div>
        );
      case 'slots':
        return (
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-6">Slot Games</h1>
            <GameGrid 
              games={mockGames.slots} 
              title="All Slots" 
              onGameClick={handleGameClick}
            />
          </div>
        );
      default:
        return (
          <div className="text-center py-20">
            <h1 className="text-2xl md:text-3xl font-bold mb-4">Coming Soon</h1>
            <p className="text-muted-foreground">This section is under development.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        user={user}
        onLoginClick={() => setShowLoginModal(true)}
        onProfileClick={() => setShowUserProfile(true)}
        onMenuClick={() => setShowMobileMenu(true)}
      />
      <div className="flex">
        {/* Desktop Sidebar */}
        <div className="hidden md:block">
          <Sidebar activeSection={activeSection} setActiveSection={setActiveSection} />
        </div>
        
        {/* Main Content */}
        <main className="flex-1 p-4 md:p-6">
          {renderContent()}
        </main>
      </div>
      
      {/* Mobile Menu */}
      <MobileMenu 
        isOpen={showMobileMenu}
        onClose={() => setShowMobileMenu(false)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />
      
      {/* Modals */}
      <GameModal game={selectedGame} onClose={closeGameModal} />
      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)}
        onLogin={handleLogin}
      />
      {showUserProfile && (
        <UserProfile 
          user={user}
          onClose={() => setShowUserProfile(false)}
          onLogout={handleLogout}
          onUpdateBalance={handleUpdateBalance}
        />
      )}
    </div>
  );
}

export default App;
